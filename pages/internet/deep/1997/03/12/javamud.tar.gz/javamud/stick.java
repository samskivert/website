
public class stick extends MudObject {
	public stick() {
		setLong("A typical stick.");
		setShort("a stick");
		setName("stick");
		setURL("http://www.netins.net/showcase/christmas/swag.1incg.gif");
	}
}
	

