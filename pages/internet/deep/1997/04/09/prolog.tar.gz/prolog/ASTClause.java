/**
 *
 * Copyright (c) 1996-1997 Sun Microsystems, Inc.
 *
 * Use of this file and the system it is part of is constrained by the
 * file COPYRIGHT in the root directory of this system.
 *
 */

import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;

public class ASTClause extends SimpleNode {
  public String name;
  public Vector args = null;
  public Hashtable bindings = new Hashtable();

  public static Node jjtCreate(String name) {
    return new ASTClause(name);
  }

  ASTClause(String name) {
    super(name);
  }

  ASTClause() {
	super("unspecified");
  }

  public String toString() {
	String s;
	Enumeration e;

	if(args == null)
		return name;

	e = args.elements();

	s = name + "(";	
	while(e.hasMoreElements()) {
		s += e.nextElement();
		if(e.hasMoreElements())
			s += ", ";
		else
			s += ")";
	}

	return s;
  }

  public boolean isFact() { return false; }
  public boolean isRule() { return false; }
}


