// package mud;

import java.util.StringTokenizer;

class join extends MudCommand {

    public void doCommand(String args)  {

		StringTokenizer st;
		String d;
		Player dest;
		Room r;
		Player[] all;
		
		if (args == null) {
			thisPlayer().write("Join who?");
			return;
		}

 		st = new StringTokenizer(args);
		d = st.nextToken();

		dest = findPlayer(d);
		r = (Room)dest.getEnvironment();

		if (dest == null) {
			thisPlayer().write("I'm sorry, that player is not connected.");
		}
		else if (dest == thisPlayer()) {
			thisPlayer().write("You can't join yourself!");
		}
		else if (r == thisPlayer().getEnvironment()) {
			thisPlayer().write("You are already in the same room!");
		}
		else {
			thisPlayer().write("You join " + dest.getName() + " in " + r + ".");
			thisPlayer().move(r);
		}
    }
}
