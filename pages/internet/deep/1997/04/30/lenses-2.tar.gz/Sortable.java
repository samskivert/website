public interface Sortable {

    //
    // Sortable public member functions
    public boolean lessThan(Sortable other);
}
