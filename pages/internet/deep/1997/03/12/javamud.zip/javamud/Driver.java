// package mud;

import java.io.*;
import java.net.*;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Enumeration;

public class Driver implements Runnable {
    static Vector connections;		/* active connctions */
    ServerSocket sock;			/* server socket */
    Thread serverThread;		/* server thread */

    public static void main(String argv[]) {
	int port = 0;			/* server port */

	/* Check arguments */
	if(argv.length != 1) {
	    System.out.println("Usage: java Driver <port>");
	    System.exit(0);
	}

	try {
	    port = Integer.parseInt(argv[0]);
	}
	catch(Exception e) {
	    System.out.println("Usage: java Driver <port>");
	    System.exit(0);
	}

	try {
	    new Driver().startServer(port);
	}
	catch(Exception e) {
	    System.out.println("Error: could not bind to port " + 
	      port + ".  Exiting.");
	    System.exit(1);
	}
    }

    public Driver() {
	connections = new Vector();
    }

    public void startServer(int port) throws IOException {
	int i;
	InetAddress addr = InetAddress.getByName(null);		/* localhost */

	try {
	    sock = new ServerSocket(port);
	}
	catch (IOException e) {
	    throw e;
	}

	serverThread = new Thread(this);
	serverThread.start();
    }

    public void open(Socket s) {
	Connection c;

	c = new Connection(s, this);
	connections.addElement(c);
    }

    public void close(Connection c) {
	c.out.close();
System.out.println("Removing player");
	Player.removePlayer(c);
	connections.removeElement(c);
    }

    public synchronized static void broadcast(Connection src, String msg) {
	Connection recipient;
	Enumeration enum;

	enum = connections.elements();

	while(enum.hasMoreElements()) {
	    recipient = (Connection)enum.nextElement();
	    if(recipient != src)
		recipient.send(msg);
	}
    }
  
    public synchronized static void broadcast(String msg) {
	Connection recipient;
	Enumeration enum = connections.elements();

	while(enum.hasMoreElements()) {
	    recipient = (Connection)enum.nextElement();
	    recipient.send(msg);
	}
    }

    public void run() {
	/* Thread.currentThread().setPriority(Thread.MAX_PRIORITY); */
	Socket s = null;

	while(true) {
	    try {
		s = sock.accept();
	    }
	    catch(Exception e) { continue; }

System.out.println("Got connection");
	    open(s);				/* open connection */
	}
    }
}

