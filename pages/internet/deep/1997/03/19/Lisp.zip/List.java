//
// List -

import java.util.Vector;

public class List extends Vector
{
}
