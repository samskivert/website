/* ASTQuestion */


public class ASTQuestion extends ASTClause {
  ASTFact goal;

  ASTQuestion(String id) {
    super(id);
  }

  ASTQuestion(ASTFact goal) {
	this.goal = goal;
  }

  public static Node jjtCreate(String id) {
    return new ASTQuestion(id);
  }

  public String toString() {
	String s = "?- ";
	return s + goal.toString();
  }
}
