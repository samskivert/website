// package mud;

class url extends MudCommand {
	public void doCommand(String args) {
		thisPlayer().setURL(args);
	}
}

