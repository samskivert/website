// package mud;

import java.util.Vector;
import java.util.Hashtable;

public class Player extends MudObject {
	private Connection conn;
	static Vector players = new Vector();
	static Hashtable connHash = new Hashtable();
	static Hashtable nameHash = new Hashtable();
	static Hashtable threadHash = new Hashtable();
	static final String default_player_url =
	  "http://iridium.astro.ubc.ca/~holland/cerebus/cerebus1.gif";

	public Player(Connection conn) {
		this.conn = conn;

		setName();
		conn.start();					/* start thread */
		players.addElement(this);
		connHash.put(conn, this);
		threadHash.put(conn.getThread(), this);
		Master.playerInit(this);
	}

	public void setName() {
		String str;

		do {
			write("What is your name?");
			str = conn.receive();
			str = str.substring(0, 1).toUpperCase() + 
			  str.substring(1).toLowerCase();

			this.name = str;

			/* already logged in */
			if(nameHash.get(name.toLowerCase()) != null)
				write("A player by that name is already logged in!");
			else
				break;

		} while(true);

		nameHash.put(name.toLowerCase(), this);
		setShort(name + " the Player");
		setLong(getShort());
	}
	
	public String getName() { return name; }
	public Connection getConnection() { return conn; }

	public void write(String msg) {
		conn.send(msg);
	}

	public static Player getPlayerByConn(Connection conn) {
		Player p;

		p = (Player)connHash.get(conn);
		return p;
	}

	public static Player getPlayerByThread(Thread t) {
		Player p;

		p = (Player)threadHash.get(t);
		return p;
	}

	public static Player getPlayerByName(String name) {
		Player p;

		p = (Player)nameHash.get(name);
		return p;
	}

	public static Player[] getAllPlayers() {
		Player[] retval;

		retval = new Player[players.size()];
		players.copyInto(retval);

		return retval;
	}

	public static void removePlayer(Connection c) {
		Player p;

		p = getPlayerByConn(c);
		if(p == null)
			return;

System.out.println("Player: removing Player");

		nameHash.remove(p.getName());
		connHash.remove(c);
		threadHash.remove(c.getThread());

		return;
	}

	boolean canGet() { return false; }

	void move(MudObject dest) {
		Room src;

		src = (Room)thisPlayer().getEnvironment();
		((Room)dest).tellRoom(thisPlayer().getName() + " arrives.");
		super.move(dest);
		src.tellRoom(thisPlayer().getName() + " leaves.");
	}

	String getURL() { 
		if(super.getURL() == null)
			return default_player_url;
		else
			return super.getURL();
	}
}


