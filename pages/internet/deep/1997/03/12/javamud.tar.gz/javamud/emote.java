// package mud;


class emote extends MudCommand {

	public void doCommand(String args)  {
		broadcast(thisPlayer(), thisPlayer().getName() + args);
		thisPlayer().write("You emote: " + thisPlayer().getName() 
		  + " " + args);
	}
}

