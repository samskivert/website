//
// Sortable - something that knows how to comapare itself to another
//            instance of itself (a wise object indeed)
//
// mdb - 02/11/97

public interface Sortable
{
    int compareTo (Sortable other);
}
