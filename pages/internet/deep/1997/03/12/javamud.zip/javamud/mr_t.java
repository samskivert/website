
public class mr_t extends MudObject implements Runnable {
	String[] sayings;

	public mr_t() {
		setLong("It's Mr. T.");
		setShort("Mr. T");
		setName("mr. t");
		setURL("http://redwood.northcoast.com/~shojo/newT.jpg");

		sayings = new String[6];
		sayings[0] =
"Mr. T says, \"I pity da fool!\"";
		sayings[1] = 
"Mr. T says, \"Has anyone seen my career?\"";
		sayings[2] =
"Mr. T says, \"Go ahead, touch my mohawk.\"";
		sayings[3] =
"Mr. T says, \"My cereal was good, dammit!\"";
		sayings[4] =
"Mr. T says, \"I melted down all my jewelry for crack money.\"";
		sayings[5] =
"Mr. T says, \"I just ate Gary Coleman, and I'm still hungry!\"";
		new Thread(this).start();
	}

	public void run() {
		while(true) {
			sleep();
			random_saying();
		}
	}

	void sleep() {
		int time;

		time = 15000 + (int)Math.floor(Math.random() * 5000);

		try {
			Thread.sleep(time);
		}
		catch(InterruptedException e) { }
	}

	void random_saying() {
		Room env;
		int index;

		env = (Room)getEnvironment();

		index = (int)Math.floor(Math.random() * sayings.length);
		env.tellRoom(sayings[index]);
	}

	public boolean canGet() { return false; }
	
}
	

