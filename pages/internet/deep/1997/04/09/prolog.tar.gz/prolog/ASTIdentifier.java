/* JJT: 0.2.2 */




public class ASTIdentifier extends SimpleNode {
  public String name;
  public boolean isConstant = false;
  public int id = 0;
 
  private static int counter = 0;

  ASTIdentifier(String name, boolean isConstant) {
    super(name);
	this.name = name;
	this.isConstant = isConstant;
	this.id = counter++;
  }

  public boolean isConstant() { return isConstant; }
  public boolean isVariable() { return !isConstant; }
  public int getId() { return id; }

  public static Node jjtCreate(String id) {
    return new ASTIdentifier(id, false);
  }
}


