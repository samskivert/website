// package mud;

import java.util.StringTokenizer;

class go extends MudCommand {
    public void doCommand(String args)  {
		String dest_name;
		Room src, dest;

		dest_name = ((Room)thisPlayer().getEnvironment()).getExit(args);

		if(dest_name == null) {
			thisPlayer().write("There is no exit that way.");
			return;
		}

		dest = Room.getRoom(dest_name);
		if(dest == null) {
			thisPlayer().write("Error: room does not exist.");
			return;
		}

		thisPlayer().move(dest);
		Master.parseCommand("look");
		return;
	}
}


