/* ASTRule */

import java.util.Vector;
import java.util.Enumeration;

public class ASTRule extends ASTClause {
  Vector conditions;

  ASTRule(String id) {
    super(id);
  }

  ASTRule(ASTFact conclusion, Vector conditions) {
	this.name = conclusion.name;
	this.args = conclusion.args;
	this.conditions = conditions;
	// System.out.println("ASTRule: " + conclusion.name);
  }

  public static Node jjtCreate(String id) {
    return new ASTRule(id);
  }

  public String toString() {
	Enumeration e;
	String s = super.toString();

	if(conditions == null)
		return s;

    e = conditions.elements();
    s += " :-\n";

    while(e.hasMoreElements()) {
        s += "  " + e.nextElement() + "\n";
    }
 
    return s;
  }

  public boolean isRule() { return true; }
}

