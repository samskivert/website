// package mud;

public class tell extends whisper {
}

