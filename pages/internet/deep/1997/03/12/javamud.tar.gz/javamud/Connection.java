// package mud;

import java.io.*;
import java.net.*;

public class Connection implements Runnable {
    static final int BUFFER_SIZE = 512;
    byte buffer[] = new byte[BUFFER_SIZE];

    Driver driver;

    private Socket s;
    private Thread t;
    public DataInputStream in;
    public PrintStream out;

    static int id_count = 1;
    int id;

    public Connection(Socket s, Driver driver) {
		this.driver = driver;
		this.s = s;

		try {
			in = new DataInputStream(s.getInputStream());
			out = new PrintStream(new 
			  BufferedOutputStream(s.getOutputStream()));
		}
		catch(IOException e) { }	/* TODO: handle errors */

		id = id_count++;		/* Unique id */
		new Player(this);
    }

    public void start() {
System.out.println("Starting conn thread");
		t = new Thread(this);		/* Thread to receive data */
		t.start();
    }

	public void run() {
		String line;

		while(t != null) {
			line = receive();
			if (line == null)
				return;
			Master.parseCommand(line);
		}
	}

	public void send(String msg) {
		out.println(msg);
		out.flush();
	}

	public String receive() {
		String data = null;

		try { 
			data = in.readLine(); 
		}
		catch(IOException e) {
System.out.println("Caught IOException in Connection");
			driver.close(this);
			return null;
		}

		return data;
	}

	public Thread getThread() {
		return t;
	}
}

