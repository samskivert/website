// package mud;

import java.util.*;

public class Master {
	private static Hashtable cmdHash = new Hashtable();
	private static Hashtable roomHash = new Hashtable();
	private static Room start_room;

	static {
		start_room = Room.getRoom("the_void");
	}

	public static synchronized void parseCommand(String line) {
		StringTokenizer st;
		String cmd, args;
	
		Class commandClass;
		Object commandOb;
		MudCommand mc;

		/* split command and trailing arguments */
		line = line.trim();

		line = expandAlias(line);
		st = new StringTokenizer(line);
		cmd = st.nextToken();

		if(cmd.length() == line.length())
			args = null;
		else
			args = line.substring(cmd.length() + 1);

		/* search hashtable for existing command object */
		mc = (MudCommand)cmdHash.get(cmd);

		if(mc != null) {			/* hashtable hit */
			mc.doCommand(args);
			return;
		}

		/* Try instantiating command object by name */
		try {
			commandClass = Class.forName(cmd);
		}
		catch(ClassNotFoundException e) {  	/* no such command */
			Player.getPlayerByThread(Thread.currentThread()).write("What?");
			return;
		}

		/* Instantiate object and place in hashtable */
		try {
			commandOb = commandClass.newInstance();
			mc = (MudCommand)commandOb;
			cmdHash.put(cmd, mc);
		}
		catch (Exception e) {
			return;
		}

		mc.doCommand(args);
	}

	public static void playerInit(Player p) {
		start_room.add(p);
	}

	public static String expandAlias(String cmd) {
		if(cmd.compareTo("e") == 0 || cmd.compareTo("east") == 0)
			return "go east";
		else if(cmd.compareTo("w") == 0 || cmd.compareTo("west") == 0)
			return "go west";
		else if(cmd.compareTo("n") == 0 || cmd.compareTo("north") == 0)
			return "go north";
		else if(cmd.compareTo("s") == 0 || cmd.compareTo("south") == 0)
			return "go south";
		else if(cmd.compareTo("u") == 0 || cmd.compareTo("up") == 0)
			return "go up";
		else if(cmd.compareTo("d") == 0 || cmd.compareTo("down") == 0)
			return "go down";
		else if(cmd.compareTo("i") == 0)
			return "inventory";
		else if(cmd.compareTo("l") == 0)
			return "look";
		else
			return cmd;
	}
}

