// package mud;

import java.util.StringTokenizer;

class drop extends MudCommand {

	public void doCommand(String args) {
		MudObject obj;

		String objname;
		Player dest;
		Player[] all;

		obj = findObject(args, thisPlayer());
		if(obj == null) {
			thisPlayer().write("There is no " + args + " here.");
			return;
		}

		obj.move(thisPlayer().getEnvironment());
		thisPlayer().write("You drop the " + obj.getName());
	}
}

