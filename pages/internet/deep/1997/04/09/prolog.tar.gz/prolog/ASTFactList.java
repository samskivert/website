/* JJT: 0.2.2 */




public class ASTFactList extends SimpleNode {
  ASTFactList(String id) {
    super(id);
  }

  public static Node jjtCreate(String id) {
    return new ASTFactList(id);
  }
}
