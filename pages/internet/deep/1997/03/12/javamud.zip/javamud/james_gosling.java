
public class james_gosling extends MudObject implements Runnable {
	String[] sayings;

	public james_gosling() {
		setLong("James Gosling");
		setShort("James Gosling");
		setName("james");
		setURL("http://java.sun.com/people/jag/jag.gif");

		sayings = new String[6];
		sayings[0] =
"James says, \"I wrote NeWS, too! That didn't pan out so well.\"";
		sayings[1] = 
"James says, \"Bill Joy has been a lot of help.\"";
		sayings[2] =
"James says, \"'The Java Language Specification' is on shelves now!\"";
		sayings[3] =
"James says, \"We really had to rush to get the AWT out on time.  We're\n" +
"sorry it sucks so much.\"";
		sayings[4] =
"James says, \"I can't believe Arthur van Hoff left us.  That\n" +
"ungrateful wretch.\"";
		sayings[5] =
"James says, \"Java is simple, object-oriented, architecture neutral,\n" +
"robust, and buzzword compliant!\"";
		new Thread(this).start();
	}

	public void run() {
		while(true) {
			sleep();
			random_saying();
		}
	}

	void sleep() {
		int time;

		time = 3000 + (int)Math.floor(Math.random() * 5000);

		try {
			Thread.sleep(time);
		}
		catch(InterruptedException e) { }
	}

	void random_saying() {
		Room env;
		int index;

		env = (Room)getEnvironment();

		index = (int)Math.floor(Math.random() * sayings.length);
		env.tellRoom(sayings[index]);
	}

	public boolean canGet() { return false; }
	
}
	

