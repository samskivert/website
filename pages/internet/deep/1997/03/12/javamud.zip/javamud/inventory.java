// package mud;

class inventory extends MudCommand {

	public void doCommand(String args)  {
		MudObject[] objs;
		String desc;

		objs = thisPlayer().getInventory();
		if(objs == null) {
			thisPlayer().write("You are empty-handed.");
			return;
		}

		thisPlayer().write("You are carrying:");
		for(int i = 0; i < objs.length; i++) {
			desc = objs[i].getShort();
			if(desc != null) {
				thisPlayer().write(objs[i].getShort());
			}
		}
	}
}

