/* JJT: 0.2.2 */




public class ASTIdentifierList extends SimpleNode {
  ASTIdentifierList(String id) {
    super(id);
  }

  public static Node jjtCreate(String id) {
    return new ASTIdentifierList(id);
  }
}
