/* ASTFact */

import java.util.Vector;

public class ASTFact extends ASTClause {
  ASTFact(String id) {
    super(id);
  }

  ASTFact(String name, Vector args) {
	this.name = name;
	this.args = args;
  }

  public static Node jjtCreate(String id) {
    return new ASTFact(id);
  }

  public String toString() {
	return super.toString() + ".";
  }

  public boolean isFact() { return true; }
}



