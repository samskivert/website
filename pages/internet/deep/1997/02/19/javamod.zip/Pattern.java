public class Pattern {
	public int[][]			ins = new int[64][4];
	public Note[][]			notes = new Note[64][4];
}
