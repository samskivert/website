// package mud;

import java.util.StringTokenizer;

class who extends MudCommand {

	public void doCommand(String args)  {
		Player[] all;

		thisPlayer().write("Connected Players:");
		all = allPlayers();
		for (int i = 0; i < all.length; i++) {
			thisPlayer().write("   " + all[i].getName());
		}
	}
}

