// package mud;

import java.util.StringTokenizer;

class look extends MudCommand {

	public void doCommand(String args) {
		MudObject obj;

		String objname;
		Player dest;
		Player[] all;

		if(args == null) {
			lookRoom();
			return;
		}

		obj = findObject(args, thisPlayer());
		if(obj == null) {
			obj = findObject(args, thisPlayer().getEnvironment());
			if(obj == null) {
				thisPlayer().write("There is no " + args + " here.");
				return;
			}
		}

		thisPlayer().write(obj.getLong());
		if(obj.getURL() != null)
			thisPlayer().write("CMD\nDISPLAY " + obj.getURL() + "\nENDCMD");
	}

	private void lookRoom() {
		MudObject env, inv[];
		String desc;

		env = thisPlayer().getEnvironment();
		inv = env.getInventory();

		thisPlayer().write(env.getLong());
		thisPlayer().write(((Room)env).getExitString());

		if(inv != null) {
			for(int i = 0; i < inv.length; i++) {
				if(inv[i] != thisPlayer()) {
					desc = inv[i].getShort();
					if(desc != null) {
						thisPlayer().write(inv[i].getShort() + ".");
					}
				}
			}
		}
	}
}

