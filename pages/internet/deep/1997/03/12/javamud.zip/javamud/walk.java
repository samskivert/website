// package mud;

public class walk extends go {
}

