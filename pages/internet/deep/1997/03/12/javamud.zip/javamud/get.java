// package mud;

import java.util.StringTokenizer;

class get extends MudCommand {

	public void doCommand(String args) {
		MudObject obj;

		String objname;
		Player dest;
		Player[] all;

		if(args == null) {
			thisPlayer().write("Get what?");
			return;
		}

		obj = findObject(args, thisPlayer().getEnvironment());

		if(obj == null) {
			thisPlayer().write("There is no " + args + " here.");
			return;
		}

		if(obj.canGet() == false) {
			thisPlayer().write("You cannot get the " + 
			  obj.getName() + ".");
			return;
		}

		obj.move(thisPlayer());
		thisPlayer().write("You get the " + obj.getName());
	}
}

