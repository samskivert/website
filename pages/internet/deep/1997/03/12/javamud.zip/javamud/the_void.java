
public class the_void extends Room {
	public the_void() {
		setLong(
"The void swirls around you, highlighting the formlessness of this\n" +
"universe, urging you wordlessly to create something.");
		setShort("The void.");
		addExit("west", "Tower");
		add(new stick());
		add(new photo());
		add(new fabio());
		add(new mr_t());
	}
}
		
