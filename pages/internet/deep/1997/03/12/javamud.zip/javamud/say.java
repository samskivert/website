// package mud;

class say extends MudCommand {

    public void doCommand(String args)  {
	broadcast(thisPlayer(), thisPlayer().getName() + " says, \"" + args +"\"");
	thisPlayer().write("You say, \"" + args + "\"");
    }
}

