//
// Nil - a null value

public class Nil
{
}
