
public class fabio extends MudObject implements Runnable {
	String[] sayings;

	public fabio() {
		setLong("Fabio, in all his glory.");
		setShort("Fabio");
		setName("fabio");
		setURL("http://redwood.northcoast.com/~shojo/fad.jpg");

		sayings = new String[6];
		sayings[0] =
"Fabio says \"Look at my pecs!\"";
		sayings[1] = 
"Fabio says, \"Did I...mention I'm huge?\"";
		sayings[2] =
"Fabio says, \"My long flowing blond hair is beautiful, no?\"";
		sayings[3] =
"Fabio says, \"It's like buttah!\"";
		sayings[4] =
"Fabio says, \"Would you like me to sign your ass?\"";
		sayings[5] =
"Fabio says, \"My large breasts love you\"";

		new Thread(this).start();
	}

	public void run() {
		while(true) {
			sleep();
			random_saying();
		}
	}

	void sleep() {
		int time;

		time = 15000 + (int)Math.floor(Math.random() * 5000);

		try {
			Thread.sleep(time);
		}
		catch(InterruptedException e) { }
	}

	void random_saying() {
		Room env;
		int index;

		env = (Room)getEnvironment();

		index = (int)Math.floor(Math.random() * sayings.length);
		env.tellRoom(sayings[index]);
	}

	public boolean canGet() { return false; }
	
}
	

