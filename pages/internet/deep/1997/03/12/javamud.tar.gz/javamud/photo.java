
public class photo extends MudObject {
	public photo() {
		setLong("This is a picture of Death.");
		setShort("a photo");
		setName("photo");
		setURL("http://sdcc8.ucsd.edu/~smarkus/death.gif");
	}
}
	

