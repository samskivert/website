// package mud;

public abstract class MudCommand extends Efun {
    public abstract void doCommand(String args);
}

