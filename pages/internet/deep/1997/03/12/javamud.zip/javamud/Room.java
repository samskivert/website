// package mud;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;

public abstract class Room extends MudObject {
	private static Hashtable roomHash = new Hashtable();
	private Hashtable exits = new Hashtable();
	private String exit_string = "Exits: none";

	public void addExit(String dir, String dest) {
		Enumeration enum;
		String str;

		exits.put(dir, dest);

		exit_string = "Exits: ";
		enum = exits.keys();
		while(enum.hasMoreElements()) {
			str = (String)enum.nextElement();
			if(enum.hasMoreElements())
				exit_string += (str + ", ");
			else
				exit_string += (str + ".");
		}
			
	}
	
	public void removeExit(String dir) {
		exits.remove(dir);
	}

	public String getExit(String dir) {
		return (String)exits.get(dir);
	}

	public String getExitString() {
		return exit_string;
	}

	public void enter(Player p) {
		tellRoom(p.getName() + " arrives.", p);
	}

	public void exit(Player p) {
		tellRoom(p.getName() + " leaves.", p);
	}

	public void tellRoom(String msg, Player p) {
		Player[] players;

		players = getPlayers();
		for(int i = 0; i < players.length; i++) {
			if(players[i] != p)
				players[i].write(msg);
		}
	}

	public void tellRoom(String msg) {
		Player[] players;

		players = getPlayers();
		if(players == null)
			return;

		for(int i = 0; i < players.length; i++) {
			players[i].write(msg);
		}
	}

	public static Room getRoom(String name) {
		Class roomClass;
		Room ret;

		ret = (Room)roomHash.get(name);
		if(ret != null)
			return ret;

		try {
			ret = (Room)(Class.forName(name)).newInstance();
		}
		catch(Exception e) {
			return null;
		}

		roomHash.put(name, ret);
		return ret;
	}

	public Player[] getPlayers() {
		Player ret[];
		MudObject objs[];
		Vector v = new Vector();

		objs = getInventory();

		if(objs == null)
			return null;

		for(int i = 0; i < objs.length; i++) {
			if(objs[i] instanceof Player) {
				v.addElement((Player)objs[i]);
			}
		}

		ret = new Player[v.size()];
		v.copyInto(ret);

		return ret;
	}
}

