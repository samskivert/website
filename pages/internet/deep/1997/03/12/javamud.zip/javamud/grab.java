// package mud;

public class grab extends get {
}

