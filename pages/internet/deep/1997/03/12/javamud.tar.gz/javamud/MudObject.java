// package mud;
import java.util.Vector;

public abstract class MudObject extends Efun {
	MudObject env = null;		/* object's environment */
	String name = null;			/* objects' name */
	
	String long_desc = null;	/* long description */
	String short_desc = null;	/* short description */
	Vector inv = new Vector();	/* inventory */
	String image_url = null;	/* URL of object's picture */	
	String audio_url = null;	/* URL of object's audio */

	/* Functions */

	String getLong() { return long_desc; } 
	String getShort() { return short_desc; }
	void setLong(String str) { long_desc = str; }
	void setShort(String str) { short_desc = str; }

	boolean canGet() { return true; }

	MudObject getEnvironment() { return env; }
	void setEnvironment(MudObject env) { this.env = env; }
	String getName() { return name; }
	void setName(String str) { name = str; }

	boolean isCalled(String str) {
		int ret;

		ret = str.toLowerCase().compareTo(name.toLowerCase());
		return (ret == 0) ? true : false;
	}

	MudObject[] getInventory() {
		MudObject[] objs = null;

		if(inv.size() == 0)
			return null;

		objs = new MudObject[inv.size()];
		inv.copyInto(objs);
		return objs;
	}

	void add(MudObject obj) {
		inv.addElement(obj);
		obj.setEnvironment(this);
	}

	void remove(MudObject obj) {
		inv.removeElement(obj);
	}

	void move(MudObject dest) {
		getEnvironment().remove(this);
		dest.add(this);
	}

	String getURL() { return image_url; }
	void setURL(String str) { image_url = str; }

	String getAudio() { return audio_url; }
	void setAudio(String str) { audio_url = str; }
}



