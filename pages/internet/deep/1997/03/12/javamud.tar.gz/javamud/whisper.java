// package mud;

import java.util.StringTokenizer;

class whisper extends MudCommand {

    public void doCommand(String args)  {
		StringTokenizer st;
		String d, toall, words;
		Player dest;
		Player[] all;

		if (args == null) {
			thisPlayer().write("Whisper to who?");
			return;
		}
 		st = new StringTokenizer(args);
		d = st.nextToken();

		if (args.substring(d.length()).compareTo("") == 0) {
			thisPlayer().write("Whisper what?");
			return;
		}
		else {
			words = args.substring(d.length() + 1);
		}

		dest = findPlayer(d);

		if (dest == null) {
			thisPlayer().write("I'm sorry, that player is not connected.");
		}
		else if (dest == thisPlayer()) {
			thisPlayer().write("You whisper to yourself: " + words);
			broadcast(thisPlayer(), thisPlayer().getName() + 
			  " is possibly crazy and is whispering to itself.");
		}
		else {
			dest.write(thisPlayer().getName() + " whispers: " + words);
			thisPlayer().write("You whisper to " + dest.getName() + 
			  " : " + words);
			toall = thisPlayer().getName() + " whispers something to " 
			  + dest.getName();
			all = allPlayers();
			for (int i = 0; i < all.length; i++) {
				if (all[i] != thisPlayer() && all[i] != dest) {
					all[i].write(toall);
				}	
			}
		}
    }
}
