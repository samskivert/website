
public class Tower extends Room {
	public Tower() {
		setLong(
"Among the swirling mists stands the Ivory Tower of Academia, its\n" +
"spire completely invisible through the vapors.  An almost overpowering\n" +
"smell of coffee fills the air."
		);

		setShort("Ivory Tower of Academia");
		addExit("east", "the_void");
		addExit("north", "barren_plain");
		add(new stick());
	}
}
		
