// package mud;

class listen extends MudCommand {

    public void doCommand(String args)  {
	MudObject env;

	env = thisPlayer().getEnvironment();
	if(env.getAudio() != null) {
		thisPlayer().write("CMD\nPLAY " + env.getAudio() + "\nENDCMD");
	}

	thisPlayer().write("You listen acutely.");
    }
}

