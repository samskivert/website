
public class barren_plain extends Room {
	public barren_plain() {
		setLong(
"Hundreds of people mill about this otherwise barren plain, laughing\n" + 
"jovially and drinking copious amounts of coffee.  Occasionally one will\n" +
"point south at the Tower of Academia and chortle especially loudly."
		);

		setShort("Plain of Opportunity");
		addExit("south", "Tower");
		add(new james_gosling());
		setAudio("http://www.acm.uiuc.edu/rml/Sounds/Sound_effects/VoicesF4.au");
	}
}
		
