// package mud;

import java.util.StringTokenizer;

class describe extends MudCommand {

	public void doCommand(String args) {
		if(args == null) {
			thisPlayer().write("You must supply a string.");
			return;
		}

		thisPlayer().setLong(thisPlayer().getShort() + "\n" + 
		  thisPlayer().getName() + " " + args);
	}
}

