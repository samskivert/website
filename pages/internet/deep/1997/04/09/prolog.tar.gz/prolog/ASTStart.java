/**
 *
 * Copyright (c) 1996-1997 Sun Microsystems, Inc.
 *
 * Use of this file and the system it is part of is constrained by the
 * file COPYRIGHT in the root directory of this system.
 *
 */

import java.util.Vector;
import java.util.Enumeration;

public class ASTStart extends SimpleNode {
  Vector facts = new Vector();
  Vector rules = new Vector();
  Vector questions = new Vector();

  public static Node jjtCreate(String id) {
    return new ASTStart(id);
  }

  ASTStart(String id){
    super(id);
  }

  public void addClause(ASTClause c) {
	if(c instanceof ASTQuestion)
		questions.addElement(c);
	else if(c instanceof ASTFact)
		facts.addElement(c);
	else
		rules.addElement(c);
  }

  public void dump() {
	Enumeration e = facts.elements();
	while(e.hasMoreElements()) {
		System.out.println(e.nextElement().toString());
	}
	e = rules.elements();
	while(e.hasMoreElements()) {
		System.out.println(e.nextElement().toString());
	}
  }
}

