import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.image.*;
import java.applet.*;
import java.util.*;

public class Client extends Frame
{
  /* gui stuff */
  private List GlobalMessages, HistoryMessages;
  private Panel TextPanel, RightPanel, ButtonPanel, DirectionGrid, LowerTextPanel;
  private Vector UserButtons;
  private ClientInputLine InputLine;
  private ClientCanvas RoomPicCanvas;

  /* socket stuff */
  private Listener LThread;		/* listens to incoming data */
  private Socket SocketToServer;	/* our connection */
  private PrintStream StreamToSocket;   /* output to this to send to server */
  private String sHostName;		/* our server name */

  /* misc stuff */
  private static int nInitPort;
  private boolean BCommandMode;

  public Client(String sHost, int nPort)
  { 
	super("JavaMUD Client");
  	DataInputStream StreamFromSocket = null;

	sHostName = sHost;
	UserButtons = new Vector(7);
	BCommandMode = false;

	System.out.println("Connecting to port " + nPort + " of server " + sHostName);

	try {
	  SocketToServer = new Socket(sHostName,nPort);
	}
	catch(UnknownHostException e) {
	  System.out.println("Couldn't find host " + sHostName);
	  System.exit(5);
	}
	catch(IOException e) {
	  System.out.println("I/O exception");
	  System.exit(5);
	}
	
 	try {
	   StreamFromSocket = new DataInputStream(
				SocketToServer.getInputStream());
	   StreamToSocket   = new PrintStream(new BufferedOutputStream(
				SocketToServer.getOutputStream()));
	}
	catch (Exception e) {
	  System.out.println("Exception while setting up I & O streams");
	  System.exit(5);
	}

	this.setLayout(new BorderLayout());

	/* The left-and-center of the screen is the text area */
  	TextPanel = new Panel();
	add("Center",TextPanel);
		TextPanel.setLayout(new BorderLayout());
		GlobalMessages = new List(10,false);
		TextPanel.add("Center",GlobalMessages);
		LowerTextPanel = new Panel();
			LowerTextPanel.setLayout(new BorderLayout());
			HistoryMessages = new List(6,false);
			LowerTextPanel.add("Center",HistoryMessages);
			InputLine = new ClientInputLine(this,58);
			LowerTextPanel.add("South",InputLine);
		TextPanel.add("South",LowerTextPanel);

	RightPanel = new Panel();
	RightPanel.setLayout(new BorderLayout());
	add("East",RightPanel);

	ButtonPanel = new Panel();
	DirectionGrid = new Panel();

	/* picture on the top of the right panel */
	RoomPicCanvas = new ClientCanvas(null);
	RoomPicCanvas.resize(200,200);
	RightPanel.add("North",RoomPicCanvas);	

	RightPanel.add("Center",DirectionGrid);
		DirectionGrid.setLayout(new GridLayout(3,3,2,2));
		DirectionGrid.add(new QuickButton("NW", "go northwest", this));
		DirectionGrid.add(new QuickButton("N", "go north", this));
		DirectionGrid.add(new QuickButton("NE", "go northeast", this));
		DirectionGrid.add(new QuickButton("W", "go west", this));
		DirectionGrid.add(new QuickButton(" ", "wait", this));
		DirectionGrid.add(new QuickButton("E", "go east", this));
		DirectionGrid.add(new QuickButton("SW", "go southwest", this));
		DirectionGrid.add(new QuickButton("S", "go south", this));
		DirectionGrid.add(new QuickButton("SE", "go southeast", this));
		
	RightPanel.add("South",ButtonPanel);
		ButtonPanel.setLayout(new GridLayout(0,1,2,2));

		Button next;

		next = new QuickButton("Don't Click Me!", "/button 0,Stop it!,oh brother", this);
		UserButtons.addElement(next); ButtonPanel.add(next);

		next = new QuickButton("Look", "look", this);
		UserButtons.addElement(next); ButtonPanel.add(next);

		next = new QuickButton("Inventory", "inventory", this);
		UserButtons.addElement(next); ButtonPanel.add(next);

		next = new QuickButton("Who", "who",this);
		UserButtons.addElement(next); ButtonPanel.add(next);

		next = new QuickButton("Quit","/quit",this);
		UserButtons.addElement(next); ButtonPanel.add(next);

	/* Make it a nice size */
	this.resize(640,480);

	LThread = new Listener(this, StreamFromSocket);
	new Thread(LThread).start();

	this.pack();
	this.show();
  }

  public void update (Graphics g)
  {
	RoomPicCanvas.repaint();
  }

  public static void main (String argv[])
  {
	if (argv.length != 2) {
		System.out.println("Usage: java Client <hostname> <portnum>");
		System.exit(0);
	}

	try { 
	    nInitPort = Integer.parseInt(argv[1]); 
	}
	catch (Exception e) {
	    System.out.println("Usage: java Client <portnum>");
	    System.exit(0); 
	}

	Client myapp = new Client(argv[0],nInitPort);	
  }
  
  public void inputLineReady()
  {
	String InputString = new String(InputLine.getText());
	InputLine.setText("");

	this.inputLineReady(InputString);
  }

  public void inputLineReady(String InputString)
  {
	if (InputString.equalsIgnoreCase("/quit")) System.exit(0);
	else if (InputString.regionMatches(0,"/button",0,7)) 
	{
		String szName, szAction=null;
		int newint;
		Integer temp;
		QuickButton tempButton;
		StringTokenizer st = new StringTokenizer(InputString.substring(8), ",");
		try {
			temp = new Integer(st.nextToken());
			newint = temp.intValue();

			if ((newint >= 0)&&(newint <= 4))
			{
				szName = st.nextToken();
				while(st.hasMoreElements())
				{
					if (szAction == null) szAction = st.nextToken(); else szAction = szAction + st.nextToken();
					if (st.hasMoreElements()) szAction = szAction + ",";
				}

				tempButton = (QuickButton) (UserButtons.elementAt(newint));

				tempButton.setButtonText(szName, szAction);
			}
		}
		catch (Exception e) {inputLineReady("Your button modification failed."); }
		return;
	}

	/* add this line to the two displays */
	GlobalMessages.addItem(InputString);
	GlobalMessages.makeVisible(GlobalMessages.countItems()-1);
  	HistoryMessages.addItem(InputString);
	HistoryMessages.makeVisible(HistoryMessages.countItems()-1);
	StreamToSocket.println(InputString);
	StreamToSocket.flush();
  }



  public void externalLineReady(String szNewText)
  {
	String szImageURL;
	URL ImageURL;

	if (BCommandMode == true)
	{
		/* Parse the commands */
		if (szNewText.startsWith("ENDCMD") == true)
			BCommandMode = false;
		else if (szNewText.startsWith("DISPLAY ") == true)
		{
			szImageURL = szNewText.substring(8);
			try { 
				Image NextImage;
				ImageURL = new URL(szImageURL);
				NextImage = java.awt.Toolkit.getDefaultToolkit().getImage(ImageURL);
				RoomPicCanvas.setImage(NextImage);
	
				System.out.println("Image is now ["+szImageURL+"]");
			}
			catch (Exception e) {
				externalLineReady("[Image URL " + szImageURL + " was invalid]");
			}
		}
		else if (szNewText.startsWith("PLAY ") == true)
		{
			String szSoundURL = szNewText.substring(6);
			URL SoundURL;

			try 
			{
				SoundURL = new URL(szSoundURL);
				System.out.println("Sounds not implemented!");
			}
			catch (Exception e) 
			{
				externalLineReady("[Sound URL " + szSoundURL + " was invalid]");
			}
		}
		else System.out.println("Error: unknown command ["+szNewText+"]");
	}
	else 
	{
		if (szNewText.startsWith("CMD") == true) BCommandMode = true;
		else
		{
			GlobalMessages.addItem(szNewText);
			GlobalMessages.makeVisible(GlobalMessages.countItems()-1);
		}
	}
  }
}
	



/* An input line customized for our purposes */
class ClientInputLine extends TextField
{
  protected Client Context;

  public ClientInputLine(Client context, int nCols)
  {
	super(nCols);
	Context = context;
  }

  public boolean keyUp(Event evt, int key)
  {
	if (key == 10)	// did they hit return?
        {
		String CheckIt = new String(getText().trim());
		if (CheckIt.length() > 0) 
		{
			setText(CheckIt);
			Context.inputLineReady();
		}
		else setText("");
        }
	return(true);
  }
}





class QuickButton extends Button
{
	Client cHostClient;
	String szIntString;

	public QuickButton(String szName, String szIntStr, Client cHost)
	{
		super(szName);
		cHostClient = cHost;
		setButtonText(szName, szIntStr);
	}

	public void setButtonText(String szName, String szIntStr)
	{
		if (szIntStr != null) szIntString = szIntStr;
		setLabel(szName);
	}

	public boolean action(Event evt, Object obj)
	{
		cHostClient.inputLineReady(szIntString);
		return true;
	}
}





class ClientCanvas extends Canvas
{
	private Image CurrentImage;
	boolean BLoading;

	public ClientCanvas(Image StartImage)
	{
		super();
		setImage(StartImage);
		repaint();
	}

	public void paint (Graphics g)
	{
		update(g);
	}

  	public void update (Graphics g)
  	{
		if (CurrentImage != null)
		{
			int width = bounds().width;
			int height = bounds().height;
			
			try {
				g.drawImage(CurrentImage, 0, 0, width, height, Color.black, null);
			} catch(Exception e) {System.out.println("hahahaha");}
		}
		if (BLoading == true)
		{
			String LString = new String("Loading");
			/* paint a "loading" message in while it loads */
			g.drawChars(LString.toCharArray(),0,7,20,20);
		}
	}

	public void loadIsDone()
	{
		BLoading = false;
	}

	public void setImage(Image NextImage)
	{
		if (NextImage != null)
		{		
  			GraphicGetter GThread;

			BLoading = true;
			repaint();

			CurrentImage = NextImage;
			GThread = new GraphicGetter(CurrentImage,this);

			new Thread(GThread).start();

		}
	}
}






class GraphicGetter implements Runnable
{
  private Image MyImage;
  private ClientCanvas CRepaintMe;
  private MediaTracker mediatracker;

  public GraphicGetter(Image WaitForMe, ClientCanvas CRM)
  {
	super();
	MyImage = WaitForMe;
	CRepaintMe = CRM;
	mediatracker = new MediaTracker(CRM);
  }

  public void run()
  {
	try 
	{
		mediatracker.addImage(MyImage,1,
			CRepaintMe.bounds().width,CRepaintMe.bounds().height);
		mediatracker.waitForID(1, 10000);
	}
	catch (Exception e) {System.out.println("Excep*"); }
	CRepaintMe.loadIsDone();
	CRepaintMe.repaint();
  }
}


	

class Listener implements Runnable
{
  private DataInputStream ListenTo;
  private Client CNotify;

  public Listener(Client CNot, DataInputStream Lto)
  {
	super();
	ListenTo = Lto;
	CNotify = CNot;
  }

  public void run()
  {
	String data;

	while(true)
	{
		data = null;
		try { data = ListenTo.readLine(); }
		catch(Exception e) 
		{
			System.out.println("Listener:  Exception!");
			return;
		}

		if (data == null)
		{
			System.out.println("Listener:  null data!");
			return;	
		}
		else 
		{
			CNotify.externalLineReady(data);
		}
	}
  }
}


