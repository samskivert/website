// package mud;

public abstract class Efun {
	public void broadcast(Player p, String msg) {
		Driver.broadcast(p.getConnection(), msg);
	}

	public void broadcast(String msg) {
		Driver.broadcast(msg);
	}

	public Player findPlayer(String name) {
		return Player.getPlayerByName(name.toLowerCase());
	}

	public Player[] allPlayers() {
		return Player.getAllPlayers();
	}

	public Player thisPlayer() {
		return Player.getPlayerByThread(Thread.currentThread());
	}

	public MudObject findObject(String name, MudObject place) {
		MudObject objects[];

		objects = place.getInventory();

		if(objects != null) {
			for(int i = 0; i < objects.length; i++) {
				if(objects[i].isCalled(name)) {
					return objects[i];
				}
			}
		}

		return null;
	}
}

